
export type DataRecord = Record<string, any>;

export interface AppState {
  originalData: DataRecord[];
  cleanedData: (DataRecord | null)[];
  currentIndex: number;
  fileName: string;
  isProcessing: boolean;
  progress: number;
  batchStatus: string;
}

export interface ProcessingResult {
  success: boolean;
  data?: DataRecord;
  error?: string;
}
