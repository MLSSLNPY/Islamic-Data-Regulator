
import React, { useState, useCallback, useRef, useMemo } from 'react';
import { 
  FileJson, 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  Save, 
  Sparkles, 
  Download,
  Loader2,
  Database,
  Search,
  CheckCircle2,
  Clock,
  Pause,
  AlertTriangle,
  Eye,
  Edit2
} from 'lucide-react';
import Papa from 'papaparse';
import * as Diff from 'diff';
import { DataRecord, AppState } from './types';
import { cleanDataRecord } from './services/geminiService';

// Yardımcı fonksiyon: Belirli bir süre bekle (ms)
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    originalData: [],
    cleanedData: [],
    currentIndex: -1,
    fileName: '',
    isProcessing: false,
    progress: 0,
    batchStatus: 'Sistem Hazır',
  });

  const [prompt, setPrompt] = useState<string>("Sıra numaralarını sil, maddelemeleri paragraf yap, atıf ifadelerini temizle. Dini kavramları ve ayet atıflarını koru.");
  const [jumpId, setJumpId] = useState<string>("");
  const [rangeStart, setRangeStart] = useState<string>("");
  const [rangeEnd, setRangeEnd] = useState<string>("");
  const [viewMode, setViewMode] = useState<'diff' | 'edit'>('diff');
  
  // İstatistikler için state
  const [stats, setStats] = useState({ success: 0, error: 0 });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const stopProcessingRef = useRef(false);

  const currentRecord = useMemo(() => 
    state.currentIndex >= 0 ? state.originalData[state.currentIndex] : null, 
  [state.currentIndex, state.originalData]);

  const currentCleanedRecord = useMemo(() => 
    state.currentIndex >= 0 ? state.cleanedData[state.currentIndex] : null, 
  [state.currentIndex, state.cleanedData]);

  // Diff Hesaplama
  const diffResult = useMemo(() => {
    if (!currentRecord || !currentCleanedRecord) return null;
    const oldText = JSON.stringify(currentRecord, null, 2);
    const newText = JSON.stringify(currentCleanedRecord, null, 2);
    return Diff.diffWordsWithSpace(oldText, newText);
  }, [currentRecord, currentCleanedRecord]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    const extension = file.name.split('.').pop()?.toLowerCase();

    reader.onload = (e) => {
      const content = e.target?.result as string;
      let parsedData: DataRecord[] = [];

      try {
        if (extension === 'json') {
          const raw = JSON.parse(content);
          parsedData = Array.isArray(raw) ? raw : [raw];
        } else if (extension === 'csv') {
          const results = Papa.parse(content, { header: true, skipEmptyLines: true });
          parsedData = results.data as DataRecord[];
        }

        if (parsedData.length === 0) throw new Error("Dosya boş veya geçersiz formatta.");

        setState({
          originalData: parsedData,
          cleanedData: new Array(parsedData.length).fill(null),
          currentIndex: 0,
          fileName: file.name,
          isProcessing: false,
          progress: 0,
          batchStatus: 'Veri Kümesi Yüklendi',
        });
        setStats({ success: 0, error: 0 });
      } catch (err) {
        alert("Dosya yükleme hatası: " + (err instanceof Error ? err.message : String(err)));
      }
    };

    reader.readAsText(file);
  };

  const processSingle = async (index: number, currentPrompt: string, data: DataRecord[]) => {
    try {
      const result = await cleanDataRecord(data[index], currentPrompt);
      return result;
    } catch (err) {
      throw err;
    }
  };

  const handleCleanCurrent = async () => {
    if (state.currentIndex === -1 || state.isProcessing) return;
    setState(prev => ({ ...prev, isProcessing: true, batchStatus: 'Mevcut kayıt işleniyor...' }));
    
    try {
      const result = await processSingle(state.currentIndex, prompt, state.originalData);
      setState(prev => {
        const newCleaned = [...prev.cleanedData];
        newCleaned[state.currentIndex] = result;
        return { ...prev, isProcessing: false, cleanedData: newCleaned, batchStatus: 'Kayıt Güncellendi' };
      });
      setViewMode('diff'); // İşlem bitince otomatik diff moduna geç
    } catch (e) {
      alert("Hata: " + e);
      setState(prev => ({ ...prev, isProcessing: false, batchStatus: 'Hata Oluştu' }));
    }
  };

  const handleBatchProcess = async (type: 'range' | 'all') => {
    if (state.originalData.length === 0 || state.isProcessing) return;

    let start = 0;
    let end = state.originalData.length - 1;

    if (type === 'range') {
      const s = parseInt(rangeStart);
      const e = parseInt(rangeEnd);
      if (isNaN(s) || isNaN(e) || s < 1 || e > state.originalData.length || s > e) {
        alert("Lütfen geçerli bir aralık girin.");
        return;
      }
      start = s - 1;
      end = e - 1;
    }

    const totalToProcess = end - start + 1;
    if (!confirm(`${totalToProcess} kayıt işlenecek. Büyük verilerde bu işlem zaman alabilir. Devam?`)) return;

    stopProcessingRef.current = false;
    setStats({ success: 0, error: 0 }); // İstatistikleri sıfırla
    
    setState(prev => ({ 
      ...prev, 
      isProcessing: true, 
      progress: 0, 
      batchStatus: 'Başlatılıyor...' 
    }));

    const dataRef = state.originalData;
    const promptRef = prompt;
    let successCount = 0;
    let errorCount = 0;

    for (let i = start; i <= end; i++) {
      if (stopProcessingRef.current) {
        break;
      }

      setState(prev => ({ 
        ...prev, 
        currentIndex: i,
        batchStatus: `İşleniyor: ${i + 1} / ${dataRef.length} (Başarılı: ${successCount}, Hata: ${errorCount})`
      }));

      let attempts = 0;
      let success = false;
      let processedData = null;

      while (attempts < 3 && !success) {
        if (stopProcessingRef.current) break;
        try {
          processedData = await processSingle(i, promptRef, dataRef);
          success = true;
        } catch (err) {
          attempts++;
          console.warn(`Kayıt ${i + 1} başarısız (Deneme ${attempts}/3). Hata:`, err);
          if (attempts < 3) {
            setState(prev => ({ ...prev, batchStatus: `Hata! 5sn bekleniyor... (Kayıt: ${i + 1})` }));
            await delay(5000); 
          }
        }
      }

      if (success && processedData) {
        successCount++;
        setState(prev => {
          const newCleaned = [...prev.cleanedData];
          newCleaned[i] = processedData;
          return { ...prev, cleanedData: newCleaned };
        });
      } else {
        errorCount++;
      }

      setStats({ success: successCount, error: errorCount });

      const currentProgress = Math.round(((i - start + 1) / totalToProcess) * 100);
      setState(prev => ({
        ...prev,
        progress: currentProgress,
      }));

      await delay(3000);
    }

    setState(prev => ({ 
      ...prev, 
      isProcessing: false, 
      batchStatus: stopProcessingRef.current ? 'İşlem durduruldu.' : `Tamamlandı! Başarılı: ${successCount}, Hata: ${errorCount}` 
    }));
    
    if (!stopProcessingRef.current) {
      alert(`İşlem Tamamlandı!\nBaşarılı: ${successCount}\nHatalı: ${errorCount}`);
    }
  };

  const saveToLocal = () => {
    if (state.currentIndex === -1) return;
    const currentView = document.getElementById('cleaned-output') as HTMLTextAreaElement;
    if (!currentView) return;
    
    try {
      const updated = JSON.parse(currentView.value);
      setState(prev => {
        const newCleaned = [...prev.cleanedData];
        newCleaned[state.currentIndex] = updated;
        return { ...prev, cleanedData: newCleaned };
      });
      alert("Değişiklikler kaydedildi.");
    } catch (e) {
      alert("Hata: Geçersiz JSON.");
    }
  };

  const exportData = (onlyCleaned: boolean) => {
    const dataToExport = state.originalData.map((original, i) => {
      return state.cleanedData[i] || original;
    });

    const extension = state.fileName.split('.').pop()?.toLowerCase() || 'json';
    let content = '';
    
    if (extension === 'csv') {
      content = Papa.unparse(dataToExport);
    } else {
      content = JSON.stringify(dataToExport, null, 2);
    }

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `temizlenmis_${state.fileName}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const goToId = () => {
    const id = parseInt(jumpId);
    if (!isNaN(id) && id >= 1 && id <= state.originalData.length) {
      setState(prev => ({ ...prev, currentIndex: id - 1 }));
      setJumpId("");
    } else {
      alert("Kayıt bulunamadı.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-100 selection:text-indigo-900">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 px-8 py-5 flex items-center justify-between shadow-sm backdrop-blur-md bg-white/90">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-violet-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
            <Sparkles size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">İslami Metin Refiner</h1>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Temizlik ve Standardizasyon Asistanı</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept=".json,.csv" />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="group flex items-center gap-2 px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition-all"
          >
            <Database size={20} className="group-hover:scale-110 transition-transform" />
            Veri Yükle
          </button>
          
          <div className="h-10 w-[1px] bg-slate-200 mx-2"></div>
          
          <button 
            onClick={() => exportData(true)}
            disabled={state.originalData.length === 0}
            className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-all shadow-xl shadow-indigo-200 disabled:opacity-50 disabled:shadow-none"
          >
            <Save size={20} />
            Sonuçları Aktar
          </button>
        </div>
      </header>

      <main className="flex-1 p-8 flex flex-col gap-8 max-w-[1800px] mx-auto w-full">
        
        <section className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col gap-8">
          <div className="flex flex-wrap items-center gap-10">
            <div className="flex items-center gap-5">
               <div className="flex flex-col gap-1.5">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Aktif Kayıt</span>
                  <div className="flex items-center gap-4">
                     <div className="bg-slate-900 text-white text-3xl font-black w-20 h-20 rounded-2xl flex items-center justify-center shadow-2xl shadow-slate-400">
                        {state.currentIndex === -1 ? '—' : state.currentIndex + 1}
                     </div>
                     <div className="flex flex-col justify-center">
                        <span className="text-lg font-black text-slate-800 tracking-tight">/ {state.originalData.length}</span>
                        <div className="flex gap-2 mt-2">
                          <button 
                            onClick={() => setState(p => ({ ...p, currentIndex: Math.max(0, p.currentIndex - 1) }))}
                            disabled={state.currentIndex <= 0 || state.isProcessing}
                            className="p-2 bg-slate-100 hover:bg-slate-200 rounded-lg disabled:opacity-30 transition-colors"
                          >
                            <ChevronLeft size={24} />
                          </button>
                          <button 
                            onClick={() => setState(p => ({ ...p, currentIndex: Math.min(p.originalData.length - 1, p.currentIndex + 1) }))}
                            disabled={state.currentIndex >= state.originalData.length - 1 || state.currentIndex === -1 || state.isProcessing}
                            className="p-2 bg-slate-100 hover:bg-slate-200 rounded-lg disabled:opacity-30 transition-colors"
                          >
                            <ChevronRight size={24} />
                          </button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-4">
                <div className="flex flex-col gap-1.5">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Kayıt No Git</span>
                  <div className="flex gap-2">
                    <input 
                      type="text" value={jumpId} onChange={e => setJumpId(e.target.value)}
                      placeholder="No" className="w-20 px-4 py-2.5 border border-slate-200 rounded-xl text-sm font-bold focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 outline-none transition-all"
                    />
                    <button onClick={goToId} className="p-2.5 bg-slate-900 text-white rounded-xl hover:bg-slate-800 shadow-lg shadow-slate-200 transition-all active:scale-95">
                      <Search size={20} />
                    </button>
                  </div>
                </div>

                <div className="h-12 w-[1px] bg-slate-200 self-end"></div>

                <div className="flex flex-col gap-1.5">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Aralık Temizle</span>
                  <div className="flex items-center gap-2 bg-slate-50 p-1.5 rounded-xl border border-slate-200 shadow-inner">
                    <input 
                      type="text" value={rangeStart} onChange={e => setRangeStart(e.target.value)}
                      placeholder="Baş" className="w-16 px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm font-bold text-center outline-none"
                    />
                    <span className="text-slate-300 font-bold">-</span>
                    <input 
                      type="text" value={rangeEnd} onChange={e => setRangeEnd(e.target.value)}
                      placeholder="Son" className="w-16 px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm font-bold text-center outline-none"
                    />
                    <button 
                      onClick={() => handleBatchProcess('range')}
                      disabled={state.isProcessing}
                      className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs font-black rounded-lg transition-all disabled:opacity-50"
                    >
                      ARALIĞI İŞLE
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-end gap-3 flex-1 justify-end">
              <button 
                onClick={handleCleanCurrent}
                disabled={state.currentIndex === -1 || state.isProcessing}
                className="group flex items-center gap-2 px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-black transition-all shadow-xl shadow-emerald-200 disabled:opacity-50 active:scale-95"
              >
                <Sparkles size={20} className="group-hover:rotate-12 transition-transform" />
                SEÇİLENİ TEMİZLE
              </button>

              {state.isProcessing ? (
                <button 
                  onClick={() => stopProcessingRef.current = true}
                  className="flex items-center gap-2 px-6 py-3.5 bg-slate-800 text-white rounded-2xl font-black transition-all animate-pulse"
                >
                  <Pause size={20} />
                  DURDUR
                </button>
              ) : (
                <button 
                  onClick={() => handleBatchProcess('all')}
                  disabled={state.originalData.length === 0}
                  className="flex items-center gap-2 px-6 py-3.5 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-black transition-all shadow-xl shadow-rose-200 disabled:opacity-50 active:scale-95"
                >
                  <Play size={20} />
                  TÜMÜNÜ TEMİZLE
                </button>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-end">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${state.isProcessing ? 'bg-indigo-600 text-white animate-pulse' : 'bg-slate-100 text-slate-400'}`}>
                  {state.isProcessing ? <Clock size={16} /> : <CheckCircle2 size={16} />}
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest leading-none mb-1">
                    {state.isProcessing ? 'İŞLENİYOR' : 'HAZIR'}
                  </h4>
                  <p className="text-xs font-bold text-slate-400">{state.batchStatus}</p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="flex gap-4 text-xs font-bold">
                  <div className="flex items-center gap-1 text-emerald-600 bg-emerald-50 px-3 py-1 rounded-lg border border-emerald-100">
                    <CheckCircle2 size={14} />
                    <span>Başarılı: {stats.success}</span>
                  </div>
                  <div className="flex items-center gap-1 text-rose-600 bg-rose-50 px-3 py-1 rounded-lg border border-rose-100">
                    <AlertTriangle size={14} />
                    <span>Hata: {stats.error}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-4xl font-black text-slate-900 tabular-nums">{state.progress}%</span>
                </div>
              </div>
            </div>
            <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden p-1 shadow-inner border border-slate-200">
              <div 
                className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-600 rounded-full transition-all duration-700 ease-out shadow-lg"
                style={{ width: `${state.progress}%` }}
              ></div>
            </div>
          </div>
        </section>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 flex-1 min-h-[600px]">
          {/* Input Panel */}
          <div className="flex flex-col gap-4 group">
             <div className="flex items-center justify-between px-2">
                <h3 className="flex items-center gap-2 text-sm font-black text-slate-800 uppercase tracking-wider">
                  <FileJson size={20} className="text-slate-400" />
                  Girdi Verisi (Orijinal)
                </h3>
                <span className="bg-slate-100 text-slate-500 text-[10px] font-black px-2 py-1 rounded-md uppercase tracking-widest">{state.fileName || 'Dosya Yok'}</span>
             </div>
             <div className="flex-1 bg-white border border-slate-200 rounded-[2rem] overflow-hidden flex flex-col shadow-lg group-hover:shadow-2xl transition-all duration-500 ring-4 ring-transparent group-hover:ring-slate-50 relative">
                <div className="bg-slate-50 px-6 py-3 border-b border-slate-200 flex justify-between items-center">
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Salt Okunur</span>
                   <span className="text-[10px] font-black text-slate-500 bg-white px-2 py-1 rounded border border-slate-100">NO: {state.currentIndex + 1}</span>
                </div>
                
                {/* Input Visualization Layer */}
                <div className="flex-1 p-8 font-mono text-sm text-slate-500 bg-white overflow-auto leading-relaxed whitespace-pre-wrap">
                  {currentRecord ? (
                    diffResult && viewMode === 'diff' ? (
                       // Show Red Highlights for removed parts
                       diffResult.map((part, i) => {
                         if (part.removed) {
                            return <span key={i} className="bg-red-100 text-red-600 line-through decoration-red-400 decoration-2 selection:bg-red-200">{part.value}</span>;
                         } else if (!part.added) {
                            return <span key={i} className="opacity-80">{part.value}</span>;
                         }
                         return null; // Don't show added parts in input view
                       })
                    ) : (
                      JSON.stringify(currentRecord, null, 2)
                    )
                  ) : "// Veri girişi bekleniyor..."}
                </div>
             </div>
          </div>

          {/* Refinement Panel */}
          <div className="flex flex-col gap-6">
            <div className="bg-gradient-to-br from-indigo-50 to-violet-50 p-6 rounded-[2rem] border border-indigo-100 shadow-inner">
               <h3 className="flex items-center gap-2 text-sm font-black text-indigo-900 uppercase tracking-wider mb-4">
                  <Sparkles size={20} className="text-indigo-600" />
                  EK TEMİZLEME TALİMATI
               </h3>
               <textarea 
                 className="w-full h-24 p-4 text-sm font-bold text-indigo-900 bg-white/50 backdrop-blur-sm border-2 border-indigo-100 rounded-2xl resize-none focus:ring-4 focus:ring-indigo-200 focus:border-indigo-400 outline-none transition-all placeholder:text-indigo-200"
                 placeholder="Varsayılan kurallara eklemek istediğiniz bir şey var mı?"
                 value={prompt}
                 onChange={e => setPrompt(e.target.value)}
                 disabled={state.isProcessing}
               ></textarea>
            </div>

            {/* Output Display */}
            <div className="flex-1 flex flex-col gap-4 group">
               <div className="flex items-center justify-between px-2">
                  <h3 className="flex items-center gap-2 text-sm font-black text-emerald-800 uppercase tracking-wider">
                    <CheckCircle2 size={20} className="text-emerald-500" />
                    Düzenlenmiş Sonuç
                  </h3>
                  <div className="flex gap-2">
                    {/* View Mode Toggles */}
                    <div className="flex bg-slate-100 rounded-lg p-1 border border-slate-200">
                      <button 
                        onClick={() => setViewMode('diff')}
                        disabled={!currentCleanedRecord}
                        className={`p-1.5 rounded-md transition-all ${viewMode === 'diff' ? 'bg-white shadow text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}
                        title="Farkları Göster"
                      >
                        <Eye size={16} />
                      </button>
                      <button 
                         onClick={() => setViewMode('edit')}
                         disabled={!currentCleanedRecord}
                         className={`p-1.5 rounded-md transition-all ${viewMode === 'edit' ? 'bg-white shadow text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}
                         title="Manuel Düzenle"
                      >
                        <Edit2 size={16} />
                      </button>
                    </div>

                    <button 
                      onClick={saveToLocal}
                      disabled={!currentCleanedRecord || viewMode === 'diff'} // Save only allowed in edit mode for simplicity
                      className="text-[10px] font-black text-emerald-600 hover:bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-100 uppercase tracking-widest transition-all disabled:opacity-30 disabled:bg-slate-50 disabled:text-slate-300 disabled:border-slate-100"
                    >
                      Kayıt Güncelle
                    </button>
                  </div>
               </div>
               <div className={`flex-1 bg-white border ${state.isProcessing ? 'border-indigo-400' : 'border-slate-200'} rounded-[2rem] overflow-hidden flex flex-col shadow-lg transition-all duration-500 relative ring-4 ${state.isProcessing ? 'ring-indigo-50' : 'ring-transparent'}`}>
                  <div className={`${state.isProcessing ? 'bg-indigo-50' : 'bg-emerald-50'} px-6 py-3 border-b ${state.isProcessing ? 'border-indigo-100' : 'border-emerald-100'} flex justify-between items-center`}>
                     <span className={`text-[10px] font-black ${state.isProcessing ? 'text-indigo-600' : 'text-emerald-600'} uppercase tracking-widest`}>
                       {state.isProcessing ? 'İŞLENİYOR' : (viewMode === 'diff' ? 'GÖRSEL (DIFF)' : 'DÜZENLEME MODU')}
                     </span>
                     <span className={`text-[10px] font-black ${state.isProcessing ? 'text-indigo-400' : 'text-emerald-400'}`}>
                        {currentCleanedRecord ? '✓ TAMAM' : (state.isProcessing ? 'AI AKTİF' : 'BOŞ')}
                     </span>
                  </div>
                  
                  {/* Output Container: Switches between Diff Div and Textarea */}
                  <div className="flex-1 relative font-mono text-sm bg-white">
                    {viewMode === 'edit' || !currentCleanedRecord || state.isProcessing ? (
                       <textarea 
                        id="cleaned-output"
                        className={`absolute inset-0 w-full h-full p-8 font-mono text-sm ${state.isProcessing ? 'text-slate-300' : 'text-slate-900'} bg-white resize-none focus:outline-none leading-relaxed transition-colors`}
                        defaultValue={currentCleanedRecord ? JSON.stringify(currentCleanedRecord, null, 2) : ""}
                        key={state.currentIndex + (currentCleanedRecord ? '_done' : '_empty') + '_edit'}
                        readOnly={state.isProcessing}
                      ></textarea>
                    ) : (
                      // Diff View for Output
                      <div className="absolute inset-0 w-full h-full p-8 overflow-auto leading-relaxed whitespace-pre-wrap text-slate-800">
                        {diffResult ? (
                           diffResult.map((part, i) => {
                             if (part.added) {
                                return <span key={i} className="bg-emerald-100 text-emerald-800 font-bold border-b-2 border-emerald-200">{part.value}</span>;
                             } else if (!part.removed) {
                                return <span key={i}>{part.value}</span>;
                             }
                             return null; // Don't show removed parts in output view
                           })
                        ) : (
                          JSON.stringify(currentCleanedRecord, null, 2)
                        )}
                      </div>
                    )}
                  </div>

                  {state.isProcessing && (
                    <div className="absolute inset-0 bg-white/40 backdrop-blur-[1px] flex flex-col items-center justify-center gap-6 z-10">
                      <div className="relative">
                        <div className="absolute inset-0 bg-indigo-600 rounded-full animate-ping opacity-25"></div>
                        <div className="relative p-5 bg-indigo-600 rounded-3xl text-white shadow-2xl shadow-indigo-300">
                          <Loader2 size={40} className="animate-spin" />
                        </div>
                      </div>
                      <div className="text-center">
                        <p className="text-indigo-900 font-black text-lg tracking-tight">Kayıt No: {state.currentIndex + 1} Temizleniyor</p>
                      </div>
                    </div>
                  )}
               </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-10">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-lg shadow-emerald-200 animate-pulse"></div>
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Motor: Gemini 3 Pro</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
              Durum: {state.cleanedData.filter(d => d !== null).length} / {state.originalData.length} Kayıt Tamamlandı
            </span>
          </div>
        </div>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Islamic Dataset Pipeline © 2025</p>
      </footer>
    </div>
  );
};

export default App;
