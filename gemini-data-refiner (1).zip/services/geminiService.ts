
import { GoogleGenAI, Type, HarmCategory, HarmBlockThreshold } from "@google/genai";
import { DataRecord } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function cleanDataRecord(
  record: DataRecord,
  userPrompt: string
): Promise<DataRecord> {
  const systemInstruction = `Sen bir "İslami metin veri temizleme ve standardizasyon asistanısın". 

GÖREVİN:
Verilen kurallara uyarak veriyi TEMİZLE ve YENİDEN DÜZENLE.

KURALLAR:

1. base_question, alt_question1, alt_question2:
- Başındaki sıra numaralarını (ör. “3.”, “4)”, “Soru 2:” vb.) tamamen sil.
- Soru anlamını KORU, sadece biçimsel temizlik yap.

2. full_answer:
- Ana metni büyük oranda KORU.
- Anlatı bütünlüğünü bozmadan şu unsurları temizle:
  - Maddeleme işaretleri: “-”, “•”, “*”
  - Atıf içeren ifadeler: örn. “daha önce gördüğümüz gibi”, “bu metinde”, “yukarıda geçtiği üzere”
- Liste mantığı varsa, maddeleri paragraf içine yedir.
- Yeni bilgi EKLEME, mevcut anlamı değiştirme.

3. short_answer:
- “Bu metin…”, “vurgulamaktadır”, “ele almaktadır” gibi metne dışarıdan referans veren ifadeleri SİL.
- Cevabı: Soru varyasyonlarıyla DOĞRUDAN uyumlu, full_answer’ın özeti olacak şekilde, kısa, net ve öğretici biçimde YENİDEN yaz.

4. GENEL İLKELER:
- Dini kavramlara sadık kal (tezkiye, takva, fücur vb.).
- Ayet numaralarına ve alıntılara DOKUNMA.
- Akademik veya vaaz üslubu ekleme. Sade, doğrudan ve temiz bir metni tercih et.

ÇIKTI FORMATI:
Sadece aşağıdaki JSON yapısını döndür:
{
  "base_question": "...",
  "alt_question1": "...",
  "alt_question2": "...",
  "full_answer": "...",
  "short_answer": "..."
}`;

  const targetKeys = ['base_question', 'alt_question1', 'alt_question2', 'full_answer', 'short_answer'];
  const allKeys = Array.from(new Set([...Object.keys(record), ...targetKeys]));

  const properties: Record<string, any> = {};
  const propertyOrdering: string[] = [];

  allKeys.forEach((key) => {
    properties[key] = {
      type: Type.STRING,
      description: `${key} alanı için temizlenmiş değer`,
    };
    propertyOrdering.push(key);
  });

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `
      Girdi Veri Kaydı:
      ${JSON.stringify(record, null, 2)}

      Kullanıcı Ek Talimatı:
      ${userPrompt}
    `,
    config: {
      systemInstruction,
      temperature: 0.3,
      maxOutputTokens: 8192, // Uzun metinler için artırıldı
      safetySettings: [
        { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_NONE },
        { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_NONE },
        { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_NONE },
        { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_NONE },
      ],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties,
        propertyOrdering,
        required: targetKeys
      },
    },
  });

  const text = response.text;
  if (!text) {
    throw new Error("Gemini'den yanıt alınamadı");
  }

  try {
    return JSON.parse(text);
  } catch (error) {
    console.error("JSON ayrıştırma hatası:", text);
    throw new Error("Yapay zeka geçersiz bir JSON döndürdü");
  }
}